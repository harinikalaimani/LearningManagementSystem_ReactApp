import 'bootstrap/dist/css/bootstrap.min.css';
import './assets/sass/style.scss';
import Router from '../../LMS-project/src/router/Router';
import DarkVariantExample from '../../LMS-project/src/component/Carousel'
import Service from '../../LMS-project/src/component/Service';
import Aboutus from '../../LMS-project/src/component/Aboutus';
import { FaGraduationCap, FaGlobe, FaHome, FaBookOpen } from "react-icons/fa";
import ServiceFully from '../../LMS-project/src/component/ServiceFully'
import WhatYouWillLearn from '../../LMS-project/src/component/WhatYouWillLearn';
function App() {
  return (
    <div className="App"> 
          <Router/>
    </div>
  );
}

export default App;
