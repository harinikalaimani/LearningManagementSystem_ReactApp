import { BrowserRouter,Routes,Route } from 'react-router-dom';
import Pstdashboard from '../../src/pages/students-pages/Pstdashboard';
import Pstjoincourse from '../../src/pages/students-pages/PstJoincourse';
import Stmycourse from '../../src/pages/students-pages/Pstmycourse';
import PstProfile from '../../src/pages/students-pages/PstProfile';
import PstReport from '../../src/pages/students-pages/PStReport';
import PstHome from '../../src/pages/students-pages/PHome';
import Pstindashboard from '../pages/students-pages/Pstindashboard';
import Pstindashboardweb from '../pages/students-pages/Pstindashboardweb';

function Router() {
  return (
    <BrowserRouter>
    <div className="">
    
        <Routes>
        <Route  path='/Home' element={<Pstdashboard />}></Route>
        <Route path='/' exact element={<PstHome/>}></Route>
        <Route path='/Mycourse' element={<Stmycourse/>}></Route>
        <Route path='/JoinCourse' element={<Pstjoincourse/>}></Route>
        <Route path='/Report' element={<PstReport/>}></Route>
        <Route path='/profile' element={<PstProfile/>}></Route>
        <Route path='students/course-index' element={<Pstindashboard/>}></Route>
        </Routes>

    </div>
    </BrowserRouter>
  );
}

export default Router;