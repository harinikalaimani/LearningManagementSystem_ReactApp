// Sidebar.js
import React from 'react';
import { Nav, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { LuHome } from "react-icons/lu";
import { RxDashboard } from "react-icons/rx";
import { LiaBookReaderSolid } from "react-icons/lia";
import { TbReport } from "react-icons/tb";
import { LuPlus } from "react-icons/lu";
import { FiUser } from "react-icons/fi";

function Sidebar() {
  const closeSidebar = () => {
    const element = document.getElementById("elementToToggle");
    element.classList.add("hidden");
  };

  return (
    <div id="elementToToggle" className="hidden">
      <div className="sidebar">
        <Nav className="nav-list">
          <Nav.Item>
            <Button variant="link" onClick={closeSidebar}>
              <i className='bx bx-x close-btn' style={{ fontSize: '25px' }}></i>
              <span className="links_name">Close</span>
            </Button>
            <span className="tooltip">Close</span>
          </Nav.Item>
          <Nav.Item>
            <Link to="/">
              <LuHome />
              <span className="links_name">Home</span>
            </Link>
            <span className="tooltip">Home</span>
          </Nav.Item>
          <Nav.Item>
            <Link to="/Home">
              <RxDashboard />
              <span className="links_name">Dashboard</span>
            </Link>
            <span className="tooltip">Dashboard</span>
          </Nav.Item>
          <Nav.Item>
            <Link to="/Mycourse">
              <LiaBookReaderSolid />
              <span className="links_name">Courses</span>
            </Link>
            <span className="tooltip">Courses</span>
          </Nav.Item>
          <Nav.Item>
            <Link to="/Report">
            <TbReport />
              <span className="links_name">Report</span>
            </Link>
            <span className="tooltip">Report</span>
          </Nav.Item>
          <Nav.Item>
            <Link to="/JoinCourse">
            <LuPlus style={{ fontSize: '25px' }}/>
              <span className="links_name">Join Course</span>
            </Link>
            <span className="tooltip">Join Course</span>
          </Nav.Item>
          <Nav.Item>
            <Link to="/profile">
            <FiUser style={{ fontSize: '25px' }}/>
              <span className="links_name">Profile</span>
            </Link>
            <span className="tooltip">Profile</span>
          </Nav.Item>
        </Nav>
      </div>
    </div>
  );
}

export default Sidebar;
