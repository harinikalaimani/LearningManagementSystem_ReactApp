import React from 'react';
import Ratio from 'react-bootstrap/Ratio';

function VideoCard() {
  return (
    <div className="col col-xxl-8 col-xl-6 mt-3 p-4 video-content">
       <Ratio aspectRatio="16x9">
        <embed type="image/svg+xml" src="https://www.youtube.com/embed/bm0OyhwFDuY?si=jXKnFbs2_QKLv8KX" />
      </Ratio>
    </div>
  );
}

export default VideoCard;
