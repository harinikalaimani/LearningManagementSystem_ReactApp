import { Form, FormControl } from 'react-bootstrap';
import React, { useEffect } from 'react';


const Sidebar = () => {
  useEffect(() => {
    // jQuery for toggle sub menus
    const handleSubMenuClick = (event) => {
      const subMenu = event.currentTarget.nextElementSibling;
      const dropdownIcon = event.currentTarget.querySelector('.dropdown');
      if (subMenu) {
        subMenu.style.display = subMenu.style.display === 'none' ? 'block' : 'none';
        dropdownIcon.classList.toggle('rotate');
      }
    };

    // jQuery for expand and collapse the sidebar
    const handleMenuBtnClick = () => {
      const sideBar = document.querySelector('.side-bar');
      const menuBtn = document.querySelector('.menu-btn');
      if (sideBar) {
        sideBar.classList.add('active');
        menuBtn.style.visibility = 'hidden';
      }
    };

    const handleCloseBtnClick = () => {
      const sideBar = document.querySelector('.side-bar');
      const menuBtn = document.querySelector('.menu-btn');
      if (sideBar) {
        sideBar.classList.remove('active');
        menuBtn.style.visibility = 'visible';
      }
    };

    // Attach event listeners
    const subBtns = document.querySelectorAll('.sub-btn');
    subBtns.forEach((subBtn) => subBtn.addEventListener('click', handleSubMenuClick));

    const menuBtn = document.querySelector('.menu-btn');
    if (menuBtn) {
      menuBtn.addEventListener('click', handleMenuBtnClick);
    }

    const closeBtn = document.querySelector('.close-btn');
    if (closeBtn) {
      closeBtn.addEventListener('click', handleCloseBtnClick);
    }

    // Cleanup event listeners on component unmount
    return () => {
      subBtns.forEach((subBtn) => subBtn.removeEventListener('click', handleSubMenuClick));
      if (menuBtn) {
        menuBtn.removeEventListener('click', handleMenuBtnClick);
      }
      if (closeBtn) {
        closeBtn.removeEventListener('click', handleCloseBtnClick);
      }
    };
  }, []); // Empty dependency array means the effect runs once after the initial render

  return (
    <div className="sidebar-container">
      {
          <div class="side-bar">
          <div className="active-cyan-3 active-cyan-4 mb-4 course-searchbox">
            <Form>
              <FormControl type="text" placeholder="Search" aria-label="Search" />
            </Form>
          </div>
            <div class="menu"> 
              <div class="item">
                <a class="sub-btn"><i class="fas fa-table"></i>Section 1: Introduction<i class="fas fa-angle-right dropdown"></i></a>
                <div class="sub-menu">
                  <div class="item">
                   <a class="sub-btn"><i class="fas fa-table"></i>Learning content<i class="fas fa-angle-right dropdown"></i></a>
                   <div class="sub-menu">
                     <a href="course-index.html" class="sub-item">Video</a>
                     <a href="/assets/resourses/java_tutorial.pdf" class="sub-item">Theory Content</a>
                   </div>
                 </div>
                 <div class="item">
                   <a class="sub-btn"><i class="fas fa-table"></i>Assessment<i class="fas fa-angle-right dropdown"></i></a>
                   <div class="sub-menu">
                     <a href="course-assessment.html" class="sub-item">Assessment 01</a>
                     <a href="course-assessment.html" class="sub-item">Assessment 02</a>
                   </div>
                 </div>
                </div>
              </div>
              <div class="item">
               <a class="sub-btn"><i class="fas fa-table"></i>Section 2: JDK<i class="fas fa-angle-right dropdown"></i></a>
               <div class="sub-menu">
                 <div class="item">
                  <a class="sub-btn"><i class="fas fa-table"></i>Learning content<i class="fas fa-angle-right dropdown"></i></a>
                  <div class="sub-menu">
                    <a href="course-index2.html" class="sub-item">Video</a>
                    <a href="/assets/resourses/java_tutorial.pdf" target="_blank" class="sub-item">Theory Content</a>
                  </div>
                </div>
                <div class="item">
                  <a class="sub-btn"><i class="fas fa-table"></i>Assessment<i class="fas fa-angle-right dropdown"></i></a>
                  <div class="sub-menu">
                    <a href="course-assessment.html" class="sub-item">Assessment 01</a>
                    <a href="course-assessment.html" class="sub-item">Assessment 02</a>
                  </div>
                </div>
               </div>
             </div>
             <div class="item">
               <a class="sub-btn"><i class="fas fa-table"></i>Section 3: How Java Works<i class="fas fa-angle-right dropdown"></i></a>
               <div class="sub-menu">
                 <div class="item">
                  <a class="sub-btn"><i class="fas fa-table"></i>Learning content<i class="fas fa-angle-right dropdown"></i></a>
                  <div class="sub-menu">
                    <a href="course-index3.html" class="sub-item">Video</a>
                    <a href="/assets/resourses/java_tutorial.pdf" target="_blank" class="sub-item">Theory Content</a>
                  </div>
                </div>
                <div class="item">
                  <a class="sub-btn"><i class="fas fa-table"></i>Assessment<i class="fas fa-angle-right dropdown"></i></a>
                  <div class="sub-menu">
                    <a href="course-assessment.html" class="sub-item">Assessment 01</a>
                    <a href="course-assessment.html" class="sub-item">Assessment 02</a>
                  </div>
                </div>
               </div>
             </div>
             <div class="item">
               <a class="sub-btn"><i class="fas fa-table"></i>Section 4: variables<i class="fas fa-angle-right dropdown"></i></a>
               <div class="sub-menu">
                 <div class="item">
                  <a class="sub-btn"><i class="fas fa-table"></i>Learning content<i class="fas fa-angle-right dropdown"></i></a>
                  <div class="sub-menu">
                    <a href="course-index.html" class="sub-item">Video</a>
                    <a href="/assets/resourses/java_tutorial.pdf" target="_blank" class="sub-item">Theory Content</a>
                  </div>
                </div>
                <div class="item">
                  <a class="sub-btn"><i class="fas fa-table"></i>Assessment<i class="fas fa-angle-right dropdown"></i></a>
                  <div class="sub-menu">
                    <a href="course-assessment.html" class="sub-item">Assessment 01</a>
                    <a href="course-assessment.html" class="sub-item">Assessment 02</a>
                  </div>
                </div>
               </div>
             </div>
             <div class="item">
               <a class="sub-btn"><i class="fas fa-table"></i>Section 5: Datatypes<i class="fas fa-angle-right dropdown"></i></a>
               <div class="sub-menu">
                 <div class="item">
                  <a class="sub-btn"><i class="fas fa-table"></i>Learning content<i class="fas fa-angle-right dropdown"></i></a>
                  <div class="sub-menu">
                    <a href="course-index2.html" class="sub-item">Video</a>
                    <a href="/assets/resourses/java_tutorial.pdf"  target="_blank" class="sub-item">Theory Content</a>
                  </div>
                </div>
                <div class="item">
                  <a class="sub-btn"><i class="fas fa-table"></i>Assessment<i class="fas fa-angle-right dropdown"></i></a>
                  <div class="sub-menu">
                    <a href="course-assessment.html" class="sub-item">Assessment 01</a>
                    <a href="course-assessment.html" class="sub-item">Assessment 02</a>
                  </div>
                </div>
               </div>
             </div>
             <div class="item">
              <a class="sub-btn"><i class="fas fa-table"></i>Section 6: Operaters<i class="fas fa-angle-right dropdown"></i></a>
              <div class="sub-menu">
                <div class="item">
                 <a class="sub-btn"><i class="fas fa-table"></i>Learning content<i class="fas fa-angle-right dropdown"></i></a>
                 <div class="sub-menu">
                   <a href="course-index3.html" class="sub-item">Video</a>
                   <a href="/assets/resourses/java_tutorial.pdf" target="_blank" class="sub-item">Theory Content</a>
                 </div>
               </div>
               <div class="item">
                 <a class="sub-btn"><i class="fas fa-table"></i>Assessment<i class="fas fa-angle-right dropdown"></i></a>
                 <div class="sub-menu">
                   <a href="course-assessment.html" class="sub-item">Assessment 01</a>
                   <a href="course-assessment.html" class="sub-item">Assessment 02</a>
                 </div>
               </div>
              </div>
            </div>
            <div class="item">
              <a class="sub-btn"><i class="fas fa-table"></i>Section 7: Conditional Statements<i class="fas fa-angle-right dropdown"></i></a>
              <div class="sub-menu">
                <div class="item">
                 <a class="sub-btn"><i class="fas fa-table"></i>Learning content<i class="fas fa-angle-right dropdown"></i></a>
                 <div class="sub-menu">
                   <a href="course-index.html" class="sub-item">Video</a>
                   <a href="/assets/resourses/java_tutorial.pdf" target="_blank" class="sub-item">Theory Content</a>
                 </div>
               </div>
               <div class="item">
                 <a class="sub-btn"><i class="fas fa-table"></i>Assessment<i class="fas fa-angle-right dropdown"></i></a>
                 <div class="sub-menu">
                   <a href="course-assessment.html" class="sub-item">Assessment 01</a>
                   <a href="course-assessment.html" class="sub-item">Assessment 02</a>
                 </div>
               </div>
              </div>
            </div>
          </div>
        </div>
      }
    </div>
  );
};

export default Sidebar;
