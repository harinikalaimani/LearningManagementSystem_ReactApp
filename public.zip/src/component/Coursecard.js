import React from 'react'
import { BiCalendar } from "react-icons/bi";
function Coursecard(props) {
  return (
    <div>
        <div class="col">
              <a href="/students/course-index" class="coursecard">
                <div class="card">
                  <img src={props.cardimg1} class="card-img-top cimg" alt="logo" />
                  <div class="card-body">
                    <h5 class="card-title">{props.cardtitle}</h5>
                    <div class="progress prog">
                      <div class="progress-bar bg-success" role="progressbar" style={{width: '25%'}} aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <p>{props.coursecompletion}completed</p>
                    <div class="d-flex date-flex mt-3">
                      <div class="card-text d-flex date-flex">
                      <BiCalendar style={{fontSize: '25px'}} />
                        <p class="mright">Start Date: <br></br>{props.sdate}</p>
                      </div>
                      <div class="card-text d-flex date-flex">
                      <BiCalendar style={{fontSize: '25px'}}/>
                        <p class="mright">End Date: <br></br>{props.edate}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </a>
        </div>
    </div>
  );
}

export default Coursecard;