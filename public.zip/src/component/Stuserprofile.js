import React from 'react';
import UserProfile from '../../src/component/UserProfile';

function Stuserprofile() {
  return (
    <UserProfile 
    ui="Kshiti123" 
    uname="Priya Ghelani" 
    email="kshitighelani@gmail.com" 
    phone="9945639745" 
    profession="Student"
    style={{ color: '' }}/>
  );
}

export default Stuserprofile;