export default function Page_heading(props){
    return(
        <h3>{props.pageheading}</h3>
    );
}