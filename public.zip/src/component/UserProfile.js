import React from 'react';

function UserProfile({ui, uname, email, phone, profession}) {
  return (
    <div className="tab-content profile-tab" id="myTabContent">
      <div className="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
        <div className="col-md-6">
          <p style={{ color: '#000' }}>Personal Information</p>
        </div>
        <div className="row mb-3">
          <div className="col-md-6">
            <label>User Id</label>
          </div>
          <div className="col-md-6">
            <p id="displayUserId">{ui}</p>
          </div>
          <div className="col-md-6">
            <label>Name</label>
          </div>
          <div className="col-md-6">
            <p id="displayName">{uname}</p>
          </div>
          <div className="col-md-6">
            <label>Email</label>
          </div>
          <div className="col-md-6">
            <p id="displayEmail">{email}</p>
          </div>
          <div className="col-md-6">
            <label>Phone</label>
          </div>
          <div className="col-md-6">
            <p id="displayPhone">{phone}</p>
          </div>
          <div className="col-md-6">
            <label>Profession</label>
          </div>
          <div className="col-md-6">
            <p id="displayProfession">{profession}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default UserProfile;
