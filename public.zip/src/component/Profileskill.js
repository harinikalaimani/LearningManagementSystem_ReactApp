import React from 'react';
import ListGroup from 'react-bootstrap/ListGroup';
function Profileskill() {
  return (
    <div className="profile-work">
     <p>SKILLS</p>
     <ul className="list-unstyled">
      <li>Web Designer</li>
      <li>Web Developer</li>
      <li>WordPress</li>
      <li>WooCommerce</li>
      <li>PHP, .Net</li>
     </ul>
    </div>
  );
}

export default Profileskill;
