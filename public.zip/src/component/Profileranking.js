import {Row} from 'react-bootstrap';
export default function Profileranking(props){
    return(
        <Row>
            <div className="col">
                <p class="proile-rating">RANKINGS : <span>{props.ProfileRanking}</span></p>
            </div>
        </Row>
        
    );
}