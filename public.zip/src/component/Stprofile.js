import React from 'react';
import {Row,Col, Button, Form, Nav,Image} from 'react-bootstrap'
import Profileranking from '../../src/component/Profileranking';
import Page_heading from '../../src/component/Page-heading';
import Profileskill from '../../src/component/Profileskill';
import Stuserprofile from '../../src/component/Stuserprofile';
import Homebtn from '../../src/component/Homebtn';
const StProfile = () => {
  return (
    <section className="home-section">
      <div className='m-left'>
      <div className="mrg-left">
        <div>
              {<Page_heading pageheading="Profile" />}
        </div>
        <Row className="ms-start ">
          <Col className="emp-profile">
            <form method="post">
              <Row className='container'>
                <Col xl={4}>
                  <div className="profile-img">
                    <Image src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS52y5aInsxSm31CvHOFHWujqUx_wWTS9iM6s7BAm21oEN_RiGoog" alt="" fluid />
                    <div className="file btn btn-lg btn-primary">
                      Change Photo
                      <Form.Control type="file" name="file" />
                    </div>
                  </div>
                </Col>
                <Col md={6}>
                  <div className="profile-head">
                  <h5>
                      Kshiti Ghelani
                  </h5>
                  <h6>
                      Student
                  </h6>
                    {<p class="proile-rating">RANKINGS : <span>8/10</span></p>}
                    <ul className="nav nav-tabs" id="myTab" role="tablist">
                      <Nav.Item>
                        <Nav.Link className="nav-link active  mt-5" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">
                          About
                        </Nav.Link>
                      </Nav.Item>
                    </ul>
                  </div>
                </Col>
                <Col xl={2} md={4}>
                  <Homebtn btnname="Edit Profile"/>
                </Col>
              </Row>
              <Row>
                <Col xl={4}>
                  {
                    <Profileskill />
                  }
                </Col>
                <Col md={8}>
                  {<Stuserprofile/>}
                </Col>
              </Row>
            </form>
          </Col>
        </Row>
      </div>
      </div>
    </section>
  );
};

export default StProfile;
