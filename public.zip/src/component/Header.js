import TopNavBar from "../component/TopNavBar";

export default function Header(){
    return(
        <TopNavBar/>
    );
}