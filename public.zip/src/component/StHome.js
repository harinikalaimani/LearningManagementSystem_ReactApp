import DarkVariantExample from '../../src/component/Carousel'
import Aboutus from '../../src/component/Aboutus';
import ServiceFully from '../../src/component/ServiceFully';
// import { Container} from 'react-bootstrap';
import { Container, Row, Col, Button } from 'react-bootstrap';
function StHome() {
  return (
    <Row className="mrg-left">
    <Col>
       <div>
         <div className="text">
            <h3>Home</h3>
         </div>
       </div>
       <Container className="ms-start">
       
       <Container>
       <DarkVariantExample/>
        <ServiceFully/>
        <Aboutus/>  
       </Container>
        
      </Container>
   </Col>
 </Row>
  );
}

export default StHome ;
