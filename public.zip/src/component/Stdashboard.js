import React from "react";
import Dashboardwelcome from "../../src/component/Dashboardwelcome";
import Page_heading from "../../src/component/Page-heading";
import Page_subheading from "../../src/component/Page-subheading";
import Coursecard from "../../src/component/Coursecard";
import Java from '../../src/assets/images/java.jpeg';
import web from '../../src/assets/images/web development.jpg';
import uiux from '../../src/assets/images/UI-UX.jpg';
import {Row} from 'react-bootstrap';
function Stdashboard() {
  const routein=()=>{
    window.location.href="./students/course-index";
  }
  const routeweb=()=>{
    window.location.href="./students/course-index/web";
  }
  return (
    <section className="home-section">
      <div className="m-left">
      <div className="mrg-left">
        <Page_heading pageheading="Dashboard" />
        <div className="container ms-start">
          <Dashboardwelcome
            username="Harini"
            welcomenote1="Welcome to our online learning platform! We're excited to have you here and help you achieve your goals."
            welcomenote2="Good Luck with your learning."
          />
        </div>
        <div className="racourse mt-4">
          <Page_subheading pagesubheading="Recently Accessed Courses" />
        </div>
        {/* <div className="row row-cols-1 row-cols-xl-4 row-cols-md-2 row-cols-lg-3 g-4 mt-2 small">
          <Coursecard
            cardimg1={Java}
            cardtitle="Programming In Java"
            coursecompletion="25%"
            sdate="21.11.23"
            edate="21.4.24"
          />
          <Coursecard
            cardimg1={web}
            cardtitle="Web Development"
            coursecompletion="25%"
            sdate="21.11.23"
            edate="21.4.24"
          />
          <Coursecard
            cardimg1={uiux}
            cardtitle="UI/UX With Figma"
            coursecompletion="25%"
            sdate="21.11.23"
            edate="21.4.24"
          />
        </div> */}
        <div  className="row row-cols-1 row-cols-xl-4 row-cols-md-2 row-cols-lg-3 g-4 mt-2 small">
          <Coursecard 
            cardimg1={Java}
            cardtitle="Programming In Java"
            coursecompletion="25%"
            sdate="21.11.23"
            edate="21.4.24"
            />
            <div onClick={routeweb}>
          <Coursecard
            cardimg1={web}
            cardtitle="Web Development"
            coursecompletion="25%"
            sdate="21.11.23"
            edate="21.4.24"
          />
  
            </div>
          <Coursecard
            cardimg1={uiux}
            cardtitle="UI/UX With Figma"
            coursecompletion="25%"
            sdate="21.11.23"
            edate="21.4.24"
          />
        </div>
        
        <div className="racourse mt-4">
          <Page_subheading pagesubheading="Upcoming Deadlines" />
        </div>
        <Row className="row-cols-1 row-cols-xl-4 row-cols-md-2 row-cols-lg-3 g-4 mt-2 small">
          <Coursecard
            cardimg1={Java}
            cardtitle="Programming In Java"
            coursecompletion="25%"
            sdate="21.11.23"
            edate="21.4.24"
          />
          <Coursecard
            cardimg1={web}
            cardtitle="Web Development"
            coursecompletion="25%"
            sdate="21.11.23"
            edate="21.4.24"
          />
          <Coursecard
            cardimg1={uiux}
            cardtitle="UI/UX With Figma"
            coursecompletion="25%"
            sdate="21.11.23"
            edate="21.4.24"
          />
        </Row>
      </div>
      </div>
    </section>
  );
}

export default Stdashboard;