import {Row} from 'react-bootstrap';
export default function Profileuserrole(props){
    return(
        <Row>
            <div className="col">
                <p class="proile-rating">RANKINGS : <span>{props.Profileuserrole}</span></p>
            </div>
        </Row>
        
    );
}