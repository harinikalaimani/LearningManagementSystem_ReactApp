import React from "react";
import JoinCourseSection from '../../component/StJoincourse';
import Header from '../../component/Header';
function Pstjoincourse() {
  return (
   <div>
     <Header/>
    <div>
    <JoinCourseSection/>
    </div>
   </div>
  );
}

export default Pstjoincourse ;