import React from 'react'
import StReport from '../../component/Streport';
import Header from '../../component/Header';
function PstReport() {
  return (
    <div>
       <Header/>
       <div>
        <StReport/>
       </div>
    </div>
  )
}

export default PstReport