import React from 'react'
import StProfile from '../../component/Stprofile';
import Header from '../../component/Header';
function PstProfile() {
  return (
    <div>
       <Header/>
       <div>
       <StProfile/>
       </div>
    </div>
  )
}

export default PstProfile;