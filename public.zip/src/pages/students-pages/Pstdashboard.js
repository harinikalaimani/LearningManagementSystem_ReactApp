import React from "react";
import Stdashboard from '../../component/Stdashboard';
import Header from '../../component/Header';
function Pstdashboard() {
  return (
    <div>
      <Header/>
      <Stdashboard/>
    </div>
  );
}

export default Pstdashboard;