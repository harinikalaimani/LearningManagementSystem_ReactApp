import React from "react";
import Stmycourse from '../../../src/component/Stmycourse';
import Header from '../../component/Header';
function Pstmycourse() {
  return (
    <div>
       <Header/>
      <div>
      <Stmycourse/>
      </div>
    </div>
  );
}

export default Pstmycourse;