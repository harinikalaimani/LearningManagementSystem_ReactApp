import Header from '../../component/Header';
import StHome from '../../component/StHome'
function PstHome() {
  return (
    <div> 
    <Header/>
    <StHome/>
    </div>
  );
}

export default PstHome ;
