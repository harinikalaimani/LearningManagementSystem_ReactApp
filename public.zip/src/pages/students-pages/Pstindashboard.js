import React from 'react'
import VideoCard from '../../component/Videocard'
import Coursedescription from '../../component/Coursedescription'
import Header from '../../component/Header'

export default function 
() {
  return (
   <>
   <Header/>
   <section className='home-section'>
   <div className='m-left '>
    <div className='mrg-left'>
      <VideoCard/>
   <Coursedescription/>
    </div>
   </div>

   </section>
   </>
  )
}
